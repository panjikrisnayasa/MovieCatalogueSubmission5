package com.panjikrisnayasa.moviecataloguesubmission5.view

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreference
import com.panjikrisnayasa.moviecataloguesubmission5.R
import com.panjikrisnayasa.moviecataloguesubmission5.model.Movie
import com.panjikrisnayasa.moviecataloguesubmission5.notification.AlarmReceiver
import com.panjikrisnayasa.moviecataloguesubmission5.viewmodel.ReleaseReminderViewModel

class NotificationFragment : PreferenceFragmentCompat(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var mAlarmReceiver: AlarmReceiver
    private lateinit var mKeyPrefDailyReminder: String
    private lateinit var mKeyPrefReleaseReminder: String
    private lateinit var mViewModel: ReleaseReminderViewModel
    private var mReleasedMovie = ArrayList<Movie>()
    private var mIsDailyPref: SwitchPreference? = null
    private var mIsReleasePref: SwitchPreference? = null

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preference, rootKey)
        init()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mAlarmReceiver = AlarmReceiver()

        mViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(ReleaseReminderViewModel::class.java)

        val tContext = context
        if (tContext != null) {
            mViewModel.setMovies(tContext)
        }
        mViewModel.getMovies().observe(this.viewLifecycleOwner, Observer { movies ->
            if (movies != null) {
                mReleasedMovie.addAll(movies)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        preferenceScreen.sharedPreferences.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onPause() {
        super.onPause()
        preferenceScreen.sharedPreferences.unregisterOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (sharedPreferences != null) {
            if (key == mKeyPrefDailyReminder) {
                if (sharedPreferences.getBoolean(mKeyPrefDailyReminder, false)) {
                    mAlarmReceiver.setRepeatingAlarm(
                        context,
                        AlarmReceiver.TYPE_DAILY_REMINDER,
                        getString(R.string.notification_message_daily)
                    )
                } else {
                    mAlarmReceiver.cancelAlarm(
                        context,
                        AlarmReceiver.TYPE_DAILY_REMINDER
                    )
                }
            } else if (key == mKeyPrefReleaseReminder) {
                if (sharedPreferences.getBoolean(mKeyPrefReleaseReminder, false)) {
                    for (i in 0 until mReleasedMovie.size) {
                        if (i > 2) return
                        mAlarmReceiver.setRepeatingReleaseAlarm(
                            context,
                            i,
                            String.format(
                                getString(R.string.notification_message_release),
                                mReleasedMovie[i].title
                            )
                        )
                        Log.d("morgan", "${mReleasedMovie[i].title} $i")
                    }
                } else {
                    mAlarmReceiver.cancelAlarm(
                        context,
                        AlarmReceiver.TYPE_RELEASE_REMINDER
                    )
                }
            }
        }
    }

    private fun init() {
        mKeyPrefDailyReminder = resources.getString(R.string.preference_key_daily_reminder)
        mIsDailyPref = findPreference(mKeyPrefDailyReminder)
        mKeyPrefReleaseReminder = resources.getString(R.string.preference_key_release_reminder)
        mIsReleasePref = findPreference(mKeyPrefReleaseReminder)
    }
}