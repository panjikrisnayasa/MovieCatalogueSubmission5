package com.panjikrisnayasa.moviecataloguesubmission5.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.panjikrisnayasa.moviecataloguesubmission5.R
import java.util.*


class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val TYPE_DAILY_REMINDER = "Daily Reminder"
        const val TYPE_RELEASE_REMINDER = "Release Reminder"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_TYPE = "type"
        const val EXTRA_CODE = "code"
        private const val ID_DAILY_REMINDER = 100
        private const val ID_RELEASE_REMINDER = 101
    }

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(EXTRA_TYPE)
        val message = intent.getStringExtra(EXTRA_MESSAGE)
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val title = if (type == TYPE_DAILY_REMINDER) TYPE_DAILY_REMINDER else message
        val notificationId =
            if (type == TYPE_DAILY_REMINDER) ID_DAILY_REMINDER else ID_RELEASE_REMINDER
        showAlarmNotification(context, title, message, notificationId, code)
    }

    fun setRepeatingAlarm(context: Context?, type: String, message: String) {
        val calendar = Calendar.getInstance()
        val pendingIntent: PendingIntent

        val alarmManager =
            context?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        intent.putExtra(EXTRA_TYPE, type)
        intent.putExtra(EXTRA_MESSAGE, message)

        calendar.set(Calendar.HOUR_OF_DAY, 7)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        pendingIntent = PendingIntent.getBroadcast(context, ID_DAILY_REMINDER, intent, 0)

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    fun setRepeatingReleaseAlarm(context: Context?, code: Int, message: String) {
        val calendar = Calendar.getInstance()
        val pendingIntent: PendingIntent

        val alarmManager =
            context?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        intent.putExtra(EXTRA_CODE, code)
        intent.putExtra(EXTRA_MESSAGE, message)


        calendar.set(Calendar.HOUR_OF_DAY, 8)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        pendingIntent = PendingIntent.getBroadcast(
            context,
            code, intent, 0
        )

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    fun cancelAlarm(context: Context?, type: String) {
        val alarmManager = context?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val requestCode =
            if (type == TYPE_DAILY_REMINDER) ID_DAILY_REMINDER else ID_RELEASE_REMINDER
        val pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, 0)
        pendingIntent.cancel()
        alarmManager.cancel(pendingIntent)
        Toast.makeText(context, "Repeating alarm cancelled", Toast.LENGTH_SHORT).show()
    }

    private fun showAlarmNotification(
        context: Context,
        title: String,
        message: String?,
        notificationId: Int,
        code: Int?
    ) {
        var channelId: String? = null
        var channelName: String? = null
        if (notificationId == ID_DAILY_REMINDER) {
            channelId = "Channel 1"
            channelName = "Alarm Manager Channel"
        } else if (notificationId == ID_RELEASE_REMINDER) {
            channelId = "Channel 2"
            channelName = "Alarm Manager Channel 2"
        }
        if (channelId != null && channelName != null) {
            val notificationManagerCompat =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_movie_grey_24dp)
                .setContentTitle(title)
                .setContentText(message)
                .setColor(ContextCompat.getColor(context, android.R.color.transparent))
                .setVibrate(longArrayOf(1000, 1000, 1000, 1000, 1000))
                .setSound(alarmSound)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(1000, 1000, 1000, 1000, 1000)
                builder.setChannelId(channelId)
                notificationManagerCompat.createNotificationChannel(channel)
            }
            val notification = builder.build()
            if (notificationId == ID_RELEASE_REMINDER) {
                if (code != null)
                    notificationManagerCompat.notify(
                        code,
                        notification
                    )
            } else {
                notificationManagerCompat.notify(notificationId, notification)
            }
        }
    }
}
